import React from 'react';
import TextoCentral from '../components/TextoCentral';

export default (comp) =>(
   <TextoCentral corFundo="#e53935">
   Tela 1
   </TextoCentral>
);
