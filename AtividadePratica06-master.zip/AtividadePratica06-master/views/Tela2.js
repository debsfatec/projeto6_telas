import React from 'react';
import TextoCentral from '../components/TextoCentral';

export default (comp) =>(
   <TextoCentral corFundo="#3b8c24">
   Tela 2
   </TextoCentral>
);
