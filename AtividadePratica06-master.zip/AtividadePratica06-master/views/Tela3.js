import React from 'react';
import TextoCentral from '../components/TextoCentral';

export default (comp) =>(
   <TextoCentral corFundo="#9932cd">
   Tela 3
   </TextoCentral>
);
