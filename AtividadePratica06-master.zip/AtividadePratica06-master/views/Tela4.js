import React from 'react';
import TextoCentral from '../components/TextoCentral';

export default (comp) =>(
   <TextoCentral corFundo="#e5f018">
   Tela 4
   </TextoCentral>
);
