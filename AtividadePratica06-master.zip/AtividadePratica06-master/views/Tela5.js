import React from 'react';
import TextoCentral from '../components/TextoCentral';

export default (comp) => (
  <TextoCentral
    corFundo="#f018cf">
    Tela 5
  </TextoCentral>
);
