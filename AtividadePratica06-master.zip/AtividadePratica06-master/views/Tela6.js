import React from 'react';
import TextoCentral from '../components/TextoCentral';

export default (comp) => (
  <TextoCentral
    corFundo="#18daf0">
    Tela 6
  </TextoCentral>
);
